<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <meta name="description" content="Marketplace for Bootstrap Admin Dashboards">
    <meta name="author" content="Bootstrap Gallery">
    <link rel="canonical" href="https://www.bootstrap.gallery/">
    <meta property="og:url" content="https://www.bootstrap.gallery/">
    <meta property="og:title" content="Admin Templates - Dashboard Templates | Bootstrap Gallery">
    <meta property="og:description" content="Marketplace for Bootstrap Admin Dashboards">
    <meta property="og:type" content="Website">
    <meta property="og:site_name" content="Bootstrap Gallery">
    <link rel="shortcut icon" href="https://adorableit.com/wp-content/uploads/2025/03/cropped-adorableIT_favicon.png">
    <link rel="stylesheet" href="assets/fonts/remix/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.min.css">
    <link rel="stylesheet" href="assets/vendor/overlay-scroll/OverlayScrollbars.min.css">
    
    <!-- Data Tables -->
    <link rel="stylesheet" href="assets/vendor/datatables/dataTables.bs5.css">
    <link rel="stylesheet" href="assets/vendor/datatables/dataTables.bs5-custom.css">
    <link rel="stylesheet" href="assets/vendor/datatables/buttons/dataTables.bs5-custom.css">
</head>
  <body>
    <div id="loading-wrapper">
      <div class='spin-wrapper'>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
      </div>
    </div>
    <div class="page-wrapper">
      <div class="app-header d-flex align-items-center">
        <div class="d-flex">
          <button class="toggle-sidebar">
            <i class="ri-menu-line"></i>
          </button>
          <button class="pin-sidebar">
            <i class="ri-menu-line"></i>
          </button>
        </div>
        <div class="app-brand ms-3">
          <a href="index.html" class="d-lg-block d-none">
            <img src="assets/images/logo.svg" class="logo" alt="Medicare Admin Template">
          </a>
          <a href="index.html" class="d-lg-none d-md-block">
            <img src="assets/images/logo-sm.svg" class="logo" alt="Medicare Admin Template">
          </a>
        </div>
        <div class="header-actions">
          <div class="search-container d-lg-block d-none mx-3">
            <input type="text" class="form-control" id="searchId" placeholder="Search">
            <i class="ri-search-line"></i>
          </div>
          <div class="d-lg-flex d-none gap-2">
            <div class="dropdown">
              <a class="dropdown-toggle header-icon" href="#!" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                <img src="assets/images/flags/1x1/fr.svg" class="header-country-flag" alt="Bootstrap Dashboards">
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-mini">
                <div class="country-container">
                  <a href="index.php" class="py-2">
                    <img src="assets/images/flags/1x1/us.svg" alt="Admin Panel">
                  </a>
                  <a href="index.php" class="py-2">
                    <img src="assets/images/flags/1x1/in.svg" alt="Admin Panels">
                  </a>
                  <a href="index.php" class="py-2">
                    <img src="assets/images/flags/1x1/br.svg" alt="Admin Dashboards">
                  </a>
                  <a href="index.php" class="py-2">
                    <img src="assets/images/flags/1x1/tr.svg" alt="Admin Templatess">
                  </a>
                  <a href="index.php" class="py-2">
                    <img src="assets/images/flags/1x1/gb.svg" alt="Google Admin">
                  </a>
                </div>
              </div>
            </div>
            <div class="dropdown">
              <a class="dropdown-toggle header-icon" href="#!" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                <i class="ri-list-check-3"></i>
                <span class="count-label warning"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-300">
                <h5 class="fw-semibold px-3 py-2 text-primary">Activity</h5>

                <!-- Scroll starts -->
                <div class="scroll300">

                  <!-- Activity List Starts -->
                  <div class="p-3">
                    <ul class="p-0 activity-list2">
                      <li class="activity-item pb-3 mb-3">
                        <a href="#!">
                          <h5 class="fw-regular">
                            <i class="ri-circle-fill text-danger me-1"></i>
                            Invoices.
                          </h5>
                          <div class="ps-3 ms-2 border-start">
                            <div class="d-flex align-items-center mb-2">
                              <div class="flex-shrink-0">
                                <img src="assets/images/products/1.jpg" class="img-shadow img-3x rounded-1"
                                  alt="Hospital Admin Templates">
                              </div>
                              <div class="flex-grow-1 ms-3">
                                23 invoices have been paid to the MediCare Labs.
                              </div>
                            </div>
                            <p class="m-0 small">10:20AM Today</p>
                          </div>
                        </a>
                      </li>
                      <li class="activity-item pb-3 mb-3">
                        <a href="#!">
                          <h5 class="fw-regular">
                            <i class="ri-circle-fill text-info me-1"></i>
                            Purchased.
                          </h5>
                          <div class="ps-3 ms-2 border-start">
                            <div class="d-flex align-items-center mb-2">
                              <div class="flex-shrink-0">
                                <img src="assets/images/products/2.jpg" class="img-shadow img-3x rounded-1"
                                  alt="Hospital Admin Templates">
                              </div>
                              <div class="flex-grow-1 ms-3">
                                28 new surgical equipments have been purchased.
                              </div>
                            </div>
                            <p class="m-0 small">04:30PM Today</p>
                          </div>
                        </a>
                      </li>
                      <li class="activity-item pb-3 mb-3">
                        <a href="#!">
                          <h5 class="fw-regular">
                            <i class="ri-circle-fill text-success me-1"></i>
                            Appointed.
                          </h5>
                          <div class="ps-3 ms-2 border-start">
                            <div class="d-flex align-items-center mb-2">
                              <div class="flex-shrink-0">
                                <img src="assets/images/products/8.jpg" class="img-shadow img-3x rounded-1"
                                  alt="Hospital Admin Templates">
                              </div>
                              <div class="flex-grow-1 ms-3">
                                36 new doctors and 28 staff members appointed.
                              </div>
                            </div>
                            <p class="m-0 small">06:50PM Today</p>
                          </div>
                        </a>
                      </li>
                      <li class="activity-item">
                        <a href="#!">
                          <h5 class="fw-regular">
                            <i class="ri-circle-fill text-warning me-1"></i>
                            Requested
                          </h5>
                          <div class="ps-3 ms-2 border-start">
                            <div class="d-flex align-items-center mb-2">
                              <div class="flex-shrink-0">
                                <img src="assets/images/products/9.jpg" class="img-shadow img-3x rounded-1"
                                  alt="Hospital Admin Templates">
                              </div>
                              <div class="flex-grow-1 ms-3">
                                Requested for 6 new vehicles for medical emergency. .
                              </div>
                            </div>
                            <p class="m-0 small">08:30PM Today</p>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="d-grid m-3">
                  <a href="javascript:void(0)" class="btn btn-primary">View all</a>
                </div>
              </div>
            </div>
            <div class="dropdown">
              <a class="dropdown-toggle header-icon" href="#!" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                <i class="ri-alarm-warning-line"></i>
                <span class="count-label success"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-300">
                <h5 class="fw-semibold px-3 py-2 text-primary">Alerts</h5>
                <div class="scroll300">
                  <div class="p-3">
                    <div class="d-flex py-2">
                      <div class="icon-box md bg-info rounded-circle me-3">
                        <span class="fw-bold fs-6 text-white">DS</span>
                      </div>
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold">Douglass Shaw</h6>
                        <p class="mb-1">
                          Appointed as a new President 2014-2025
                        </p>
                        <p class="small m-0 opacity-50">Today, 07:30pm</p>
                      </div>
                    </div>
                    <div class="d-flex py-2">
                      <div class="icon-box md bg-danger rounded-circle me-3">
                        <span class="fw-bold fs-6 text-white">WG</span>
                      </div>
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold">Willie Garrison</h6>
                        <p class="mb-1">
                          Congratulate, James for new job.
                        </p>
                        <p class="small m-0 opacity-50">Today, 08:00pm</p>
                      </div>
                    </div>
                    <div class="d-flex py-2">
                      <div class="icon-box md bg-warning rounded-circle me-3">
                        <span class="fw-bold fs-6 text-white">TJ</span>
                      </div>
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold">Terry Jenkins</h6>
                        <p class="mb-1">
                          Lewis added new doctors training schedule.
                        </p>
                        <p class="small m-0 opacity-50">Today, 09:30pm</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="d-grid m-3">
                  <a href="javascript:void(0)" class="btn btn-primary">View all</a>
                </div>
              </div>
            </div>
            <div class="dropdown">
              <a class="dropdown-toggle header-icon" href="#!" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                <i class="ri-message-3-line"></i>
                <span class="count-label"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-300">
                <h5 class="fw-semibold px-3 py-2 text-primary">Messages</h5>
                <div class="scroll300">
                  <div class="p-3">
                    <div class="d-flex py-2">
                      <img src="assets/images/user3.png" class="img-shadow img-3x me-3 rounded-5"
                        alt="Hospital Admin Templates">
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold">Nick Gonzalez</h6>
                        <p class="mb-1">
                          Appointed as a new President 2014-2025
                        </p>
                        <p class="small m-0 opacity-50">Today, 07:30pm</p>
                      </div>
                    </div>
                    <div class="d-flex py-2">
                      <img src="assets/images/user1.png" class="img-shadow img-3x me-3 rounded-5"
                        alt="Hospital Admin Templates">
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold">Clyde Fowler</h6>
                        <p class="mb-1">
                          Congratulate, James for new job.
                        </p>
                        <p class="small m-0 opacity-50">Today, 08:00pm</p>
                      </div>
                    </div>
                    <div class="d-flex py-2">
                      <img src="assets/images/user4.png" class="img-shadow img-3x me-3 rounded-5"
                        alt="Hospital Admin Templates">
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold">Sophie Michiels</h6>
                        <p class="mb-1">
                          Lewis added new doctors training schedule.
                        </p>
                        <p class="small m-0 opacity-50">Today, 09:30pm</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="d-grid m-3">
                  <a href="javascript:void(0)" class="btn btn-primary">View all</a>
                </div>
              </div>
            </div>
          </div>
          <div class="dropdown ms-2">
            <a id="userSettings" class="dropdown-toggle d-flex align-items-center" href="#!" role="button"
              data-bs-toggle="dropdown" aria-expanded="false">
              <div class="avatar-box">JB<span class="status busy"></span></div>
            </a>
            <div class="dropdown-menu dropdown-menu-end shadow-lg">
              <div class="px-3 py-2">
                <span class="small">Admin</span>
                <h6 class="m-0">James Bruton</h6>
              </div>
              <div class="mx-3 my-2 d-grid">
                <a href="logout.php" class="btn btn-danger">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="main-container">
      <nav id="sidebar" class="sidebar-wrapper">
        <div class="sidebar-profile">
          <img src="assets/images/user6.png" class="img-shadow img-3x me-3 rounded-5" alt="Hospital Admin Templates">
          <div class="m-0">
            <h5 class="mb-1 profile-name text-nowrap text-truncate">Sachin Verma</h5>
            <p class="m-0 small profile-name text-nowrap text-truncate">Dev Admin</p>
          </div>
        </div>
        <div class="sidebarMenuScroll">
          <ul class="sidebar-menu">
            <li class="treeview">
              <a href="#!">
                <i class="ri-heart-pulse-line"></i>
                <span class="menu-text">Dashboard</span>
              </a>
              <ul class="treeview-menu">
                <li>
                  <a href="pindex.php">Client Dashboard</a>
                </li>
                <li>
                  <a href="index.php">Vendor Dashboard</a>
                </li>
                <li>
                  <a href="index.php">Employee Dashboard</a>
                </li>
              </ul>
            </li>
            
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Projects</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">All Project</a>
                  </li>
                  <li>
                    <a href="#">Add Project</a>
                  </li>
                  <li>
                    <a href="#">Estimates</a>
                  </li>
                  <li>
                    <a href="#">Project Details</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Employees</span>
                </a>
                <ul class="treeview-menu active-sub">
                  <li>
                    <a href="patients-list.php">All Employee</a>
                  </li>
                  <li>
                    <a href="add-patient.php">Add Employee</a>
                  </li>
                  <li>
                    <a href="edit-user.php">Edit Employee</a>
                  </li>
                  <li>
                    <a href="#">Employee Shift</a>
                  </li>
                  <li>
                    <a href="#">Employee Profile</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Leave Management</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">All Leave Request</a>
                  </li>
                  <li>
                    <a href="#">Leave Balance</a>
                  </li>
                  <li>
                    <a href="#">Leave Types</a>
                  </li>
                  <li>
                    <a href="#">Leave Settings</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Attendance</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Today's Attendance</a>
                  </li>
                  <li>
                    <a href="#">Employee Attendance</a>
                  </li>
                  <li>
                    <a href="#">Attendance Sheet</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Holidays</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">All Holidays</a>
                  </li>
                  <li>
                    <a href="#">Add Holidays</a>
                  </li>
                  <li>
                    <a href="#">Edit Holidays</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Clients</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">All Clients</a>
                  </li>
                  <li>
                    <a href="#">Add Clients</a>
                  </li>
                  <li>
                    <a href="#">Edit Clients</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Payroll</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Employee Salary</a>
                  </li>
                  <li>
                    <a href="#">Payslip</a>
                  </li>
                </ul>
              </li>
              <li class="">
                <a href="#">
                  <i class="ri-home-5-line"></i>
                  <span class="menu-text">Leader</span>
                </a>
              </li>
               <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Jobs</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Jobs List</a>
                  </li>
                  <li>
                    <a href="#">Resumes</a>
                  </li>
                  <li>
                    <a href="#">Candidates</a>
                  </li>
                  <li>
                    <a href="#">Shortlist Candidates</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Departments</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">All Departments</a>
                  </li>
                  <li>
                    <a href="#">Add Department</a>
                  </li>
                  <li>
                    <a href="#">Edit Department</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Training</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Training List</a>
                  </li>
                  <li>
                    <a href="#">Trainers</a>
                  </li>
                  <li>
                    <a href="#">Training Types</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Accounts</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Client Payments</a>
                  </li>
                  <li>
                    <a href="#">Add Payments</a>
                  </li>
                  <li>
                    <a href="#">Invoice</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Reports</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Leave Report</a>
                  </li>
                  <li>
                    <a href="#">Expense Reports</a>
                  </li>
                </ul>
              </li>
              <li class="">
                <a href="#">
                  <i class="ri-home-5-line"></i>
                  <span class="menu-text">Task</span>
                </a>
              </li>
              <li class="">
                <a href="#">
                  <i class="ri-home-5-line"></i>
                  <span class="menu-text">Contacts</span>
                </a>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Email</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Inbox</a>
                  </li>
                  <li>
                    <a href="#">Compose</a>
                  </li>
                  <li>
                    <a href="#">Read Mail</a>
                  </li>
                </ul>
              </li>
               <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Authentication</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="#">Sign In</a>
                  </li>
                  <li>
                    <a href="#">Sign Up</a>
                  </li>
                  <li>
                    <a href="#">Forgot Password</a>
                  </li>
                  <li>
                    <a href="#">Locked</a>
                  </li>
                </ul>
              </li>
               <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Logout</span>
                </a>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-nurse-line"></i>
                  <span class="menu-text">Staff</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="members-list.php">Members List</a>
                  </li>
                  <li>
                    <a href="add-member.php" class="active-sub">Add Member</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text">Salaries</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="salary-list.php" class="active-sub">Salary List</a>
                  </li>
                  <li>
                    <a href="#">Payslip</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
              <a href="#!">
                <i class="ri-heart-pulse-line"></i>
                <span class="menu-text">Patients</span>
              </a>
              <ul class="treeview-menu">
                <li>
                  <a href="patient-dashboard.php">Users Dashboard</a>
                </li>
                <li>
                  <a href="patients-list.php">Users List</a>
                </li>
                <li>
                  <a href="add-patient.php">Add User</a>
                </li>
                <li>
                  <a href="edit-user.php">Edit User Details</a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="sidebar-contact">
          <p class="fw-light mb-1 text-nowrap text-truncate">Emergency Contact</p>
          <h5 class="m-0 lh-1 text-nowrap text-truncate">0987654321</h5>
          <i class="ri-phone-line"></i>
        </div>
      </nav>