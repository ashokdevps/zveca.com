<?php
$hostname = "localhost";
$user = "root";
$password = "";
$dbname = "login_register";

session_start();

$mysqli = new mysqli($hostname, $user, $password, $dbname);
if ($mysqli->connect_errno) {
    die('Database connection failed: ' . $mysqli->connect_error);
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // sanitize and validate
    $username = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    $pass_confirm = $_POST['password_confirm'] ?? '';

    if ($username === '') {
        $errors[] = 'Username is required.';
    }

    if ($pass === '') {
        $errors[] = 'Password is required.';
    }

    if ($pass !== $pass_confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        // check if username exists
        $stmt = $mysqli->prepare('SELECT id FROM it_login WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors[] = 'Username already taken. Choose another.';
            $stmt->close();
        } else {
            $stmt->close();

            // insert new user with hashed password
            $hashed = password_hash($pass, PASSWORD_DEFAULT);
            $usertype = 'user'; // default

            $ins = $mysqli->prepare('INSERT INTO it_login (username, password, usertype) VALUES (?, ?, ?)');
            if (!$ins) {
                $errors[] = 'Prepare failed: ' . $mysqli->error;
            } else {
                $ins->bind_param('sss', $username, $hashed, $usertype);
                if ($ins->execute()) {
                    $success = 'Registration successful. You can <a href="login.php">login here</a>.';
                    // optionally redirect: header('Location: login.php'); exit();
                } else {
                    $errors[] = 'Registration failed: ' . $ins->error;
                }
                $ins->close();
            }
        }
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register</title>
    <style>
        body { font-family: Arial, Helvetica, sans-serif; background:#f7f7f7; }
        .card { max-width:420px; margin:40px auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
        label { display:block; margin-bottom:6px; }
        input[type=text], input[type=password] { width:95%; padding:10px; margin-bottom:12px; border:1px solid #ccc; border-radius:4px; }
        .btn { padding:10px 16px; border:none; background:#0066cc; color:#fff; border-radius:4px; cursor:pointer; }
        .errors { background:#ffe6e6; padding:10px; margin-bottom:12px; border-radius:4px; color:#900; }
        .success { background:#e6ffe6; padding:10px; margin-bottom:12px; border-radius:4px; color:#060; }
        .small { font-size:0.9rem; color:#666; }
    </style>
</head>
<body  >

<div class="card">
    <h2>Create an account</h2>

    <?php if (!empty($errors)): ?>
        <div class="errors">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>">
        </div>

        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div>
            <label for="password_confirm">Confirm password</label>
            <input type="password" id="password_confirm" name="password_confirm" required>
        </div>

        <div>
            <input class="btn" type="submit" value="Register">
        </div>

        <p class="small">Already have an account? <a href="login.php">Login here</a>.</p>
    </form>
</div>

</body>
</html>
