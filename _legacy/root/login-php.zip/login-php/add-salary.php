<?php include 'includes/header.php'; ?>
<div class="app-container">

  <!-- App hero header starts -->
  <div class="app-hero-header d-flex align-items-center">

    <!-- Breadcrumb starts -->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item text-primary" aria-current="page">
        Add Member
      </li>
    </ol>
    <!-- Breadcrumb ends -->

    <!-- Sales stats starts -->
    <div class="ms-auto d-lg-flex d-none flex-row">
      <div class="d-flex flex-row gap-1 day-sorting">
        <button class="btn btn-sm btn-primary">Today</button>
        <button class="btn btn-sm">7d</button>
        <button class="btn btn-sm">2w</button>
        <button class="btn btn-sm">1m</button>
        <button class="btn btn-sm">3m</button>
        <button class="btn btn-sm">6m</button>
        <button class="btn btn-sm">1y</button>
      </div>
    </div>
    <!-- Sales stats ends -->

  </div>
  <!-- App Hero header ends -->

  <!-- App body starts -->
  <div class="app-body">

    <!-- Row starts -->
    <div class="row gx-3">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header">
            <h5 class="card-title">Add Salary Details</h5>
          </div>
          <div class="card-body">

            <form action="scode.php" method="POST">
            <!-- Row starts -->
            <div class="row gx-3">
              <div class="col-xxl-3 col-lg-6 col-sm-6">
                <div class="mb-3">
                  <label class="form-label" for="a1">Emp Name <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" name="emp_name" id="a1" placeholder="Enter Name">
                </div>
              </div>
              <div class="col-xxl-3 col-lg-6 col-sm-6">
                <div class="mb-3">
                  <label class="form-label" for="a10">Position</label>
                  <input type="text" class="form-control" name="position" id="a10" placeholder="Enter Position">
                </div>
              </div>
              <div class="col-xxl-3 col-lg-6 col-sm-6">
                <div class="mb-3">
                  <label class="form-label" for="a10">Location</label>
                  <input type="text" class="form-control" name="location" id="a10" placeholder="Enter Location">
                </div>
              </div>
              <div class="col-xxl-3 col-lg-6 col-sm-6">
                <div class="mb-3">
                  <label class="form-label" for="a2">Working Days <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" name="working_days" id="a2" placeholder="Enter Working Days">
                </div>
              </div>
              <div class="col-xxl-3 col-lg-6 col-sm-6">
                <div class="mb-3">
                  <label class="form-label" for="a3">Month <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" name="month" id="a3" placeholder="Enter Month">
                </div>
              </div>
              <div class="col-xxl-3 col-lg-6 col-sm-6">
                <div class="mb-3">
                  <label class="form-label" for="a4">Salary <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" name="salary" id="a4" placeholder="Enter Salary">
                </div>
              </div>

              <div class="col-sm-12">
                <div class="d-flex gap-2 justify-content-end">
                  <a href="salary-list.php" type="button" class="btn btn-outline-secondary">
                    Cancel
                  </a>
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
            </div>
            <!-- Row ends -->
            </form>

          </div>
        </div>
      </div>
    </div>
    <!-- Row ends -->

  </div>
  <!-- App body ends -->

  <!-- App footer starts -->
  <div class="app-footer bg-white">
    <span>© Adorableit admin 2025</span>
  </div>
  <!-- App footer ends -->

</div>
<?php include 'includes/footer.php'; ?>