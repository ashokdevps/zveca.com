<?php
$hostname = "localhost";
$user = "root";
$password = "";
$dbname = "login_register";

session_start();

$mysqli = new mysqli($hostname, $user, $password, $dbname);
if ($mysqli->connect_errno) {
    die('Database connection failed: ' . $mysqli->connect_error);
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';

    if ($username === '' || $pass === '') {
        $errors[] = 'Username and password are required.';
    } else {
        $stmt = $mysqli->prepare('SELECT id, password, usertype FROM it_login WHERE username = ? LIMIT 1');
        if (!$stmt) {
            $errors[] = 'Prepare failed: ' . $mysqli->error;
        } else {
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $stmt->bind_result($id, $hashed_pass, $usertype);
                $stmt->fetch();

                if (password_verify($pass, $hashed_pass)) {
                    // login success
                    $_SESSION['username'] = $username;
                    $_SESSION['user_id'] = $id;
                    $_SESSION['usertype'] = $usertype;

                    if ($usertype === 'admin') {
                        header('Location: /login-php/');
                        exit();
                    } else {
                        header('Location: userhome.php');
                        exit();
                    }
                } else {
                    $errors[] = 'Username or password incorrect.';
                }
            } else {
                $errors[] = 'Username or password incorrect.';
            }

            $stmt->close();
        }
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <style>
        body { font-family: Arial, Helvetica, sans-serif; background:#f7f7f7; }
        .card { max-width:420px; margin:40px auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
        label { display:block; margin-bottom:6px; }
        input[type=text], input[type=password] { width:100%; padding:10px; margin-bottom:12px; border:1px solid #ccc; border-radius:4px; }
        .btn { padding:10px 16px; border:none; background:#0066cc; color:#fff; border-radius:4px; cursor:pointer; }
        .errors { background:#ffe6e6; padding:10px; margin-bottom:12px; border-radius:4px; color:#900; }
        .small { font-size:0.9rem; color:#666; }
    </style>
</head>
<body>

<div class="card">
    <h2>Login to your account</h2>

    <?php if (!empty($errors)): ?>
        <div class="errors">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>">
        </div>

        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div>
            <input class="btn" type="submit" value="Login">
        </div>

        <p class="small">Don't have an account? <a href="register.php">Create one</a>.</p>
    </form>
</div>

</body>
</html>
