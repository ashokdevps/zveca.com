<?php
session_start();


if(!isset($_SESSION["username"]))
{
  header("location:login.php");
}
?>

<?php include 'includes/header.php'; ?>
<div class="app-container">

  <!-- App hero header starts -->
  <div class="app-hero-header d-flex align-items-center">

    <!-- Breadcrumb starts -->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item text-primary" aria-current="page">
        Dashboard
      </li>
    </ol>
    <!-- Breadcrumb ends -->

    <!-- Sales stats starts -->
    <div class="ms-auto d-lg-flex d-none flex-row">
      <div class="d-flex flex-row gap-1 day-sorting">
        <button class="btn btn-sm btn-primary">Today</button>
        <button class="btn btn-sm">7d</button>
        <button class="btn btn-sm">2w</button>
        <button class="btn btn-sm">1m</button>
        <button class="btn btn-sm">3m</button>
        <button class="btn btn-sm">6m</button>
        <button class="btn btn-sm">1y</button>
      </div>
    </div>
    <!-- Sales stats ends -->

  </div>
  <!-- App Hero header ends -->

  <!-- App body starts -->
  <div class="app-body">

    <!-- Row starts -->
    <div class="row gx-3">
      <div class="col-xxl-12 col-sm-12">
        <div class="card mb-3 bg-2">
          <div class="card-body">
            <div class="py-4 px-3 text-white">
              <h6>Good Morning,</h6>
              <h2>Dr. Patrick Kim</h2>
              <h5>Your schedule today.</h5>
              <div class="mt-4 d-flex gap-3">
                <div class="d-flex align-items-center">
                  <div class="icon-box lg bg-arctic rounded-3 me-3">
                    <i class="ri-surgical-mask-line fs-4"></i>
                  </div>
                  <div class="d-flex flex-column">
                    <h2 class="m-0 lh-1">9</h2>
                    <p class="m-0">Patients</p>
                  </div>
                </div>
                <div class="d-flex align-items-center">
                  <div class="icon-box lg bg-lime rounded-3 me-3">
                    <i class="ri-lungs-line fs-4"></i>
                  </div>
                  <div class="d-flex flex-column">
                    <h2 class="m-0 lh-1">3</h2>
                    <p class="m-0">Surgeries</p>
                  </div>
                </div>
                <div class="d-flex align-items-center">
                  <div class="icon-box lg bg-peach rounded-3 me-3">
                    <i class="ri-walk-line fs-4"></i>
                  </div>
                  <div class="d-flex flex-column">
                    <h2 class="m-0 lh-1">2</h2>
                    <p class="m-0">Discharges</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Row ends -->

    <!-- Row starts -->
    <div class="row gx-3">
      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="p-2 border border-success rounded-circle me-3">
                <div class="icon-box md bg-success-subtle rounded-5">
                  <i class="ri-surgical-mask-line fs-4 text-success"></i>
                </div>
              </div>
              <div class="d-flex flex-column">
                <h2 class="lh-1">890</h2>
                <p class="m-0">New Patients</p>
              </div>
            </div>
            <div class="d-flex align-items-end justify-content-between mt-1">
              <a class="text-success" href="javascript:void(0);">
                <span>View All</span>
                <i class="ri-arrow-right-line text-success ms-1"></i>
              </a>
              <div class="text-end">
                <p class="mb-0 text-success">+40%</p>
                <span class="badge bg-success-subtle text-success small">this month</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="p-2 border border-primary rounded-circle me-3">
                <div class="icon-box md bg-primary-subtle rounded-5">
                  <i class="ri-lungs-line fs-4 text-primary"></i>
                </div>
              </div>
              <div class="d-flex flex-column">
                <h2 class="lh-1">360</h2>
                <p class="m-0">OPD Patients</p>
              </div>
            </div>
            <div class="d-flex align-items-end justify-content-between mt-1">
              <a class="text-primary" href="javascript:void(0);">
                <span>View All</span>
                <i class="ri-arrow-right-line ms-1"></i>
              </a>
              <div class="text-end">
                <p class="mb-0 text-primary">+30%</p>
                <span class="badge bg-primary-subtle text-primary small">this month</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="p-2 border border-danger rounded-circle me-3">
                <div class="icon-box md bg-danger-subtle rounded-5">
                  <i class="ri-microscope-line fs-4 text-danger"></i>
                </div>
              </div>
              <div class="d-flex flex-column">
                <h2 class="lh-1">980</h2>
                <p class="m-0">Lab tests</p>
              </div>
            </div>
            <div class="d-flex align-items-end justify-content-between mt-1">
              <a class="text-danger" href="javascript:void(0);">
                <span>View All</span>
                <i class="ri-arrow-right-line ms-1"></i>
              </a>
              <div class="text-end">
                <p class="mb-0 text-danger">+60%</p>
                <span class="badge bg-danger-subtle text-danger small">this month</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="p-2 border border-warning rounded-circle me-3">
                <div class="icon-box md bg-warning-subtle rounded-5">
                  <i class="ri-money-dollar-circle-line fs-4 text-warning"></i>
                </div>
              </div>
              <div class="d-flex flex-column">
                <h2 class="lh-1">$98000</h2>
                <p class="m-0">Total Earnings</p>
              </div>
            </div>
            <div class="d-flex align-items-end justify-content-between mt-1">
              <a class="text-warning" href="javascript:void(0);">
                <span>View All</span>
                <i class="ri-arrow-right-line ms-1"></i>
              </a>
              <div class="text-end">
                <p class="mb-0 text-warning">+20%</p>
                <span class="badge bg-warning-subtle text-warning small">this month</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Row ends -->

    <!-- Row starts -->
    <div class="row gx-3">
      <div class="col-xl-2 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex flex-column align-items-center">
              <div class="icon-box md rounded-5 bg-primary mb-3">
                <i class="ri-verified-badge-line fs-4 lh-1"></i>
              </div>
              <h6>Appointments</h6>
              <h2 class="text-primary m-0">639</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-2 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex flex-column align-items-center">
              <div class="icon-box md rounded-5 bg-primary mb-3">
                <i class="ri-stethoscope-line fs-4 lh-1"></i>
              </div>
              <h6>Doctors</h6>
              <h2 class="text-primary m-0">83</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-2 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex flex-column align-items-center">
              <div class="icon-box md rounded-5 bg-primary mb-3">
                <i class="ri-psychotherapy-line fs-4 lh-1"></i>
              </div>
              <h6>Staff</h6>
              <h2 class="text-primary m-0">296</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-2 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex flex-column align-items-center">
              <div class="icon-box md rounded-5 bg-primary mb-3">
                <i class="ri-lungs-line fs-4 lh-1"></i>
              </div>
              <h6>Operations</h6>
              <h2 class="text-primary m-0">49</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-2 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex flex-column align-items-center">
              <div class="icon-box md rounded-5 bg-primary mb-3">
                <i class="ri-hotel-bed-line fs-4 lh-1"></i>
              </div>
              <h6>Admitted</h6>
              <h2 class="text-primary m-0">372</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-2 col-sm-6 col-12">
        <div class="card mb-3">
          <div class="card-body">
            <div class="d-flex flex-column align-items-center">
              <div class="icon-box md rounded-5 bg-primary mb-3">
                <i class="ri-walk-line fs-4 lh-1"></i>
              </div>
              <h6>Discharged</h6>
              <h2 class="text-primary m-0">253</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Row ends -->

    <!-- Row starts -->
    <div class="row gx-3">
      <div class="col-xxl-12 col-sm-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title">Available Beds</h5>
          </div>
          <div class="card-body">
            <div id="availableBeds"></div>
          </div>
        </div>
      </div>
      <div class="col-xxl-6 col-sm-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title">Patients</h5>
          </div>
          <div class="card-body">
            <div id="patients"></div>
          </div>
        </div>
      </div>
      <div class="col-xxl-6 col-sm-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title">Treatment Type</h5>
          </div>
          <div class="card-body">
            <div id="treatment"></div>
          </div>
        </div>
      </div>
      <div class="col-xxl-6 col-sm-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title">Hospital Earnings</h5>
          </div>
          <div class="card-body">

            <!-- Row start -->
            <div class="row g-3">
              <div class="col-sm-6 col-12">
                <div class="border rounded-2 d-flex align-items-center flex-row p-2">
                  <div class="me-2">
                    <div id="sparkline1"></div>
                  </div>
                  <div class="m-0">
                    <div class="d-flex align-items-center">
                      <h4 class="m-0 fw-bold">$4900</h4>
                      <div class="ms-2 text-primary d-flex">
                        <small>20%</small> <i class="ri-arrow-right-up-line ms-1 fw-bold"></i>
                      </div>
                    </div>
                    <small>Online Consultation</small>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-12">
                <div class="border rounded-2 d-flex align-items-center flex-row p-2">
                  <div class="me-2">
                    <div id="sparkline2"></div>
                  </div>
                  <div class="m-0">
                    <div class="d-flex align-items-center">
                      <div class="fs-4 fw-bold">$750</div>
                      <div class="ms-2 text-danger d-flex">
                        <small>26%</small> <i class="ri-arrow-right-down-line ms-1 fw-bold"></i>
                      </div>
                    </div>
                    <small class="text-dark">Overall Purchases</small>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-12">
                <div class="border rounded-2 d-flex align-items-center flex-row p-2">
                  <div class="me-2">
                    <div id="sparkline3"></div>
                  </div>
                  <div class="m-0">
                    <div class="d-flex align-items-center">
                      <div class="fs-4 fw-bold">$560</div>
                      <div class="ms-2 text-primary d-flex">
                        <small>28%</small> <i class="ri-arrow-right-up-line ms-1 fw-bold"></i>
                      </div>
                    </div>
                    <small class="text-dark">Pending Invoices</small>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-12">
                <div class="border rounded-2 d-flex align-items-center flex-row p-2">
                  <div class="me-2">
                    <div id="sparkline4"></div>
                  </div>
                  <div class="m-0">
                    <div class="d-flex align-items-center">
                      <div class="fs-4 fw-bold">$390</div>
                      <div class="ms-2 text-primary d-flex">
                        <small>30%</small> <i class="ri-arrow-right-up-line ms-1 fw-bold"></i>
                      </div>
                    </div>
                    <small class="text-dark">Monthly Billing</small>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row ends -->

          </div>
        </div>
      </div>
      <div class="col-xxl-3 col-sm-6">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title">Insurance Claims</h5>
          </div>
          <div class="card-body">
            <div id="claims"></div>
          </div>
        </div>
      </div>
      <div class="col-xxl-3 col-sm-6">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title">Patients by Gender</h5>
          </div>
          <div class="card-body">
            <div class="auto-align-graph">
              <div id="genderAge"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Row ends -->

  </div>
  <!-- App body ends -->

  <!-- App footer starts -->
  <div class="app-footer bg-white">
    <span>© Medflex admin 2024</span>
  </div>
  <!-- App footer ends -->

</div>
<?php include 'includes/footer.php'; ?>